'''
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>
'''

'''
Samantha Bennefield
1/130/17
Mr. Davis
Animation
'''

import random, pygame, sys
from pygame.locals import *
import time

pygame.init()

FPS = 15
fpsClock = pygame.time.Clock()

# Variables for width and height of the window
WINDOWWIDTH = 500
WINDOWHEIGHT = 400

mousex = 0  # <--Stores x coordinate of mouse event
mousey = 0  # <--Stores y coordinate of mouse event

# Display set up
DISPLAYSURF = pygame.display.set_mode((WINDOWWIDTH, WINDOWHEIGHT))
pygame.display.set_caption('Game')

# Colors
#            R    G    B
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
NAVYBLUE = (60, 60, 100)

# Mario Img
Img = pygame.image.load('mario2.gif')
newX = 20  # <--Starting X
newY = 100 # <--Starting Y

# Quit Box
quitImg = pygame.image.load('quitBtn1.png')  # <--Quit Box default
quitImg2 = pygame.image.load('quitBtn2.png')  # <--Quit Box clicked
quitX = 10  # <--Quit box X location
quitY = 10  # <--Quit box Y location

# Save Box
saveImg = pygame.image.load('saveBtn1.png')  # <--Save Box default
saveImg2 = pygame.image.load('saveBtn2.png')  # <--Save Box clicked
saveX = 370  # <--Save box X location
saveY = 10   # <--Save box Y location

# Load Box
loadImg = pygame.image.load('loadBtn1.png')  # <--Load Box default
loadImg2 = pygame.image.load('loadBtn2.png')  # <--Load Box clicked
loadX = 190  # <--Load box X location
loadY = 10   # <--Load box Y location

# Koopa Img
koopaImg = pygame.image.load('koopa.png')  # <--Load Box default
koopaX = 100  # <--Koopa X location
koopaY = 330  # <--Koopa Y location
direction = 'right'

# Sound Effect
soundObj = pygame.mixer.Sound('jump.wav')

# Game loop
while True:
    mouseClicked = False

    DISPLAYSURF.fill(NAVYBLUE)

    DISPLAYSURF.blit(koopaImg, (koopaX, koopaY))
    DISPLAYSURF.blit(Img, (newX, newY))
    DISPLAYSURF.blit(quitImg, (quitX, quitY))
    DISPLAYSURF.blit(saveImg, (saveX, saveY))
    DISPLAYSURF.blit(loadImg, (loadX, loadY))

    for event in pygame.event.get():
        if event.type == QUIT or (event.type == KEYUP and event.key == K_ESCAPE):
            pygame.quit()
            sys.exit()

        elif event.type == MOUSEMOTION:
            mousex, mousey = event.pos

        elif event.type == MOUSEBUTTONDOWN:
            mousex, mousey = event.pos
            mouseClicked = True

            x = newX  # <--X value before click
            y = newY  # <--Y value before click

            newX = mousex  # <--X location on click
            newY = mousey  # <--Y location on click

            if newX >= 350 and newY <= 50:  # <--If it's over the Save box
                DISPLAYSURF.blit(saveImg, (saveX, saveY))  # <--Changing the Save box color
                pygame.time.wait(100)

                # Resets the X and Y so the cat doesn't move
                # new position = original position
                newX = x
                newY = y

                newX2 = koopaX
                newY2 = koopaY

                # Saving the cat's location to locations.txt
                f = open('locations.txt', 'w')
                xStr = str(newX) #Convert mario X location to String
                yStr = str(newY) #Convert mario Y location to String

                xStr2 = str(newX2)  # Convert koopa X location to String
                yStr2 = str(newY2)  # Convert koopa Y location to String

                f.write(xStr+" "+yStr)
                f.write(xStr2+" "+yStr2)
                f.close()

            elif newX <= 85 and newY <= 50:  # <--If it's over the Quit box
                DISPLAYSURF.blit(quitImg2, (quitX, quitY))  # <--Changing the Quit box color
                pygame.time.wait(100)

                # Resets the X and Y so the cat doesn't move
                # new position = original position
                newX = x
                newY = y

                # Exits the program
                pygame.quit()
                sys.exit()

            elif newX >= 100 and newY >= 50: #<--If it's over the Load Box
                DISPLAYSURF.blit(loadImg2, (loadX, loadY))  # <--Changing the Load box color
                pygame.time.wait(100)

                # Resets the X and Y so the cat doesn't move
                # new position = original position
                newX = x
                newY = y

                #Loads location
                f = open('locations.txt', 'r')
                loc = f.readline()
                location = loc.split()

                savedXstr = location[0]
                savedYstr = location[1]

                #savedXstr2 = location[2]
                #savedYstr2 = location[3]

                savedX = int(savedXstr)
                savedY = int(savedYstr)

                #savedX2 = int(savedXstr2)
                #savedY2 = int(savedYstr2)

                DISPLAYSURF.blit(Img, (savedX, savedY))
                #DISPLAYSURF.blit(koopaImg, (savedX2, savedY2))

                f.close()

            else:
                if newY>=340:
                    # Resets the X and Y so the cat doesn't move
                    # new position = original position
                    newX = x
                    newY = y
                elif newX>=380:
                    # Resets the X and Y so the cat doesn't move
                    # new position = original position
                    newX = x
                    newY = y
                else:
                    DISPLAYSURF.blit(Img, (newX, newY))  # <--Move cat to clicked position
                    DISPLAYSURF.blit(koopaImg, (koopaX, koopaY))
                    soundObj.play()  # <--Play the sound on movement
                    print(newX, newY)

        elif event.type == KEYUP:
            if event.key in (K_LEFT, K_a):#Left Arrow or A is pressed
                newX -= 10
            elif event.key in (K_UP,K_w):#Up Arrow or W is pressed
                newY -= 10
            elif event.key in (K_DOWN,K_s):#Down Arrow or S is pressed
                newY += 10
            elif event.key in (K_RIGHT,K_d):#Right Arrow or D is pressed
                newX += 10
            elif event.key in (K_LEFT, K_j):  # Left Arrow or A is pressed
                koopaX -= 10
            elif event.key in (K_UP, K_i):  # Up Arrow or W is pressed
                koopaY -= 10
            elif event.key in (K_DOWN, K_k):  # Down Arrow or S is pressed
                koopaY += 10
            elif event.key in (K_RIGHT, K_l):  # Right Arrow or D is pressed
                koopaX += 10

    pygame.display.update()
